import { Test, TestingModule } from '@nestjs/testing';
import { SensorsController } from './sensors.controller.js';
import { SensorsService } from './sensors.service.js';

describe('SensorController', () => {
  let controller: SensorsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [SensorsController],
      providers: [SensorsService],
    }).compile();

    controller = module.get<SensorsController>(SensorsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
