import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Catalogo {
  @PrimaryGeneratedColumn()
  id_catalogo: number;

  @Column({ length: 250 })
  titulo: string;

  @Column({ length: 250 })
  autor: string;

  @Column({ length: 20 })
  isbn: string;

  @Column({ length: 250 })
  editorial: string;

  @Column({ type: 'smallint' })
  anio: number;

  @Column({ length: 100 })
  genero: string;

  @Column({ length: 100 })
  idioma: string;

  @Column()
  numero_paginas: number;

  @Column({ length: 250 })
  ubicacion: string;

  @Column({ type: 'mediumtext', nullable: true })
  imagen_1: string | null;

  @Column({ type: 'mediumtext', nullable: true })
  imagen_2: string | null;

  @Column({ type: 'mediumtext', nullable: true })
  imagen_3: string | null;

  @Column({ type: 'mediumtext', nullable: true })
  imagen_4: string | null;
}

