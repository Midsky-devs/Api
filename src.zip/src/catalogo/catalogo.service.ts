import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateCatalogoDto } from './dto/create-catalogo.dto.js';
import { UpdateCatalogoDto } from './dto/update-catalogo.dto.js';
import { Catalogo } from './entities/catalogo.entity.js';

@Injectable()
export class CatalogoService {
  
  constructor(
    @InjectRepository(Catalogo, 'mariadb-connection')
    private readonly catalogoRepository: Repository<Catalogo>,
  ) {}

  async create(data: CreateCatalogoDto) {
    const libro = this.catalogoRepository.create(data);
    return this.catalogoRepository.save(libro);
  }

  async findAll() {
    return this.catalogoRepository.find();
  }

  async findOne(id_catalogo: number) {
    return this.catalogoRepository.findOneBy({ id_catalogo });
  }

  async update(id_catalogo: number, data: UpdateCatalogoDto) {
    return this.catalogoRepository.update(id_catalogo, data);
  }

  async remove(id_catalogo: number) {
    return this.catalogoRepository.delete(id_catalogo);
  }
}
