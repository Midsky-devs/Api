import { Type } from 'class-transformer';
import {
  IsInt,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  MinLength,
} from 'class-validator';

export class CreateCatalogoDto {
  @IsString()
  @MinLength(1)
  @MaxLength(250)
  titulo: string;

  @IsString()
  @MinLength(1)
  @MaxLength(250)
  autor: string;

  @IsString()
  @MinLength(1)
  @MaxLength(20)
  isbn: string;

  @IsString()
  @MinLength(1)
  @MaxLength(250)
  editorial: string;

  @Type(() => Number)
  @IsInt()
  @Min(1000)
  @Max(2050)
  anio: number;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  genero: string;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  idioma: string;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  numero_paginas: number;

  @IsString()
  @MinLength(1)
  @MaxLength(300)
  ubicacion: string;

  @IsOptional()
  @IsString()
  imagen_1?: string;

  @IsOptional()
  @IsString()
  imagen_2?: string;

  @IsOptional()
  @IsString()
  imagen_3?: string;

  @IsOptional()
  @IsString()
  imagen_4?: string;
}
