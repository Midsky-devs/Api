import { Controller, Get, Post, Body, Patch, Param, Delete, ValidationPipe } from '@nestjs/common';
import { CreateCatalogoDto } from './dto/create-catalogo.dto.js';
import { UpdateCatalogoDto } from './dto/update-catalogo.dto.js';
import { CatalogoService } from './catalogo.service.js';

@Controller('catalogo')
export class CatalogoController {
  constructor(private readonly catalogoService: CatalogoService) {}

  @Post()
  create(@Body(ValidationPipe) createCatalogoDto: CreateCatalogoDto) {
    return this.catalogoService.create(createCatalogoDto);
  }

  @Get()
  findAll() {
    return this.catalogoService.findAll();
  }

  @Get(':id_catalogo')
  findOne(@Param('id_catalogo') id_catalogo: number) {
    return this.catalogoService.findOne(id_catalogo);
  }

  @Patch(':id_catalogo')
  update(@Param('id_catalogo') id_catalogo: number,@Body(ValidationPipe) updateCatalogoDto: UpdateCatalogoDto,) {
    return this.catalogoService.update(id_catalogo, updateCatalogoDto);
  }

  @Delete(':id_catalogo')
  remove(@Param('id_catalogo') id_catalogo: number) {
    return this.catalogoService.remove(id_catalogo);
  }
}
