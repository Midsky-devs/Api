import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Catalogo } from './entities/catalogo.entity.js';
import { CatalogoController } from './catalogo.controller.js';
import { CatalogoService } from './catalogo.service.js';

@Module({
  imports: [TypeOrmModule.forFeature([Catalogo], 'mariadb-connection')],
  controllers: [CatalogoController],
  providers: [CatalogoService],
})
export class CatalogoModule {}
