import { Module } from '@nestjs/common';
import { createObserveModule } from '@nestjs/observe';
import { AppController } from './app.controller.js';
import { AppService } from './app.service.js';
import { UsersModule } from './users/users.module.js';
import { SensorsModule } from './sensors/sensors.module.js';
import { TareaModule } from './tarea/tarea.module.js';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CatalogoModule } from './catalogo/catalogo.module.js';
import { LibroModule } from './libro/libro.module.js';



export const { ObserveModule, ObserveInstrument } = createObserveModule();

@Module({
  imports: [
    TypeOrmModule.forRoot({
      name: 'postgres-connection',
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'admin',
      password: 'StrongPassword123!',
      database: 'DSM43',
      autoLoadEntities: true,
      synchronize: true,
    }),

    TypeOrmModule.forRoot({
      name: 'mariadb-connection',
      type: 'mariadb',
      host: 'localhost',
      port: 3306,
      username: 'kzsv_app',
      password: 'K120924z',
      database: 'DSM43',
      autoLoadEntities: true,
      synchronize: true,
    }),

    TypeOrmModule.forRoot({
      name: 'mssql-connection',
      type: 'mssql',
      host: 'localhost',
      port: 1433,
      username: 'sa',
      password: 'StrongPassword123!',
      database: 'DSM43',
      autoLoadEntities: true,
      synchronize: true,
      options: {
        encrypt: false,
        trustServerCertificate: true,
      },
    }),

    UsersModule,
    SensorsModule,
    TareaModule,
    CatalogoModule,
    LibroModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}